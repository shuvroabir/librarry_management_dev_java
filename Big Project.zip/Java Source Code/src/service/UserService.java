package service;

import java.util.List;

import dao.UserDao;
import entity.User;

public class UserService {
	private UserDao userDao;
	

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}
	 
	public void register(User user){
		this.userDao.register(user);
		
	}
	public boolean login(User user){
		return this.userDao.login(user);
	}
	
	public void addUser(User user){
		this.userDao.add(user);
		
	}
	
	public void updateUser(User user){
		this.userDao.update(user);
		
	}
	
	public void deleteUser(User user){
		this.userDao.delete(user);
	
	}
	
	public User findUserById(Integer id){
		return this.userDao.findById(id);
		
	}
	
	public List<User> findAllUser(){
		return this.userDao.findAll();
	
	}
}