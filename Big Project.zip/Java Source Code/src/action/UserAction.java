package action;

import service.UserService;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import entity.User;

public class UserAction extends ActionSupport implements ModelDriven<User> {

	
	private User user = new User();
	@Override
	public User getModel() {
		return this.user;
	}
	
	@Override
	public String execute() throws Exception {
	
		return SUCCESS;
	}
	
	private UserService userService;
	public void setUserService(UserService userService){
		this.userService = userService;
		
	}
	public String add(){
		this.userService.addUser(user);
		return "add";
		
		
	}
	
	public String register(){
		
		ActionContext actionContext = ActionContext.getContext();
		if(user.getUserName().equals("")){
			actionContext.put("msg", "UserName can not be null.");
			return "registerError";
		}
		if(user.getPassword().equals("")){
			actionContext.put("msg", "Password can not be null.");
			return "registerError";
		}
		if(user.getRepeatPassword().equals("")){
			actionContext.put("msg", "RepeatPassword can not be null.");
			return "registerError";
		}
		if(user.getRepeatPassword().equals(user.getPassword()) == false){
			actionContext.put("msg", "Password and RepeatPassword must be same.");
			return "registerError";
		}
		this.userService.register(user);
		return "register";
		
	}
		
	public String login(){
		ActionContext actionContext = ActionContext.getContext();
		
		boolean isSuccess = this.userService.login(user);
		if (isSuccess){
			actionContext.getSession().put("user", "user");
			return "loginSuccess";
	}
		else{
			actionContext.put("msg", "login fail.");
			return "loginFail";
		}
	}
	
	public String singOut(){
		ActionContext actionContext = ActionContext.getContext();
		actionContext.getSession().clear();

		
		
		return "signOut";
	}
	
}
