package dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import utils.HibernateSessionFactory;
import entity.User;

public class UserDao {
	
	public void register(User user){
		add(user);
	}
	
	public boolean login(User user){
		Session session = HibernateSessionFactory.getSession();
		Transaction tran = session.beginTransaction();
		String hql = "from User where userName='%s' and password='%s'";
		hql = String.format(hql, user.getUserName(), user.getPassword());
		Query query = session.createQuery(hql);
		List<User> list= query.list();
		tran.commit();
		session.close();
		
		if (list != null && list.size() > 0)
			return true;
		else
			return false;
		
	}
	
	
	public void add(User user){
		Session session = HibernateSessionFactory.getSession();
		Transaction tran = session.beginTransaction();
		
		session.save(user);
		
		tran.commit();
		session.close();
	}
	
	public void update(User user){
		Session session = HibernateSessionFactory.getSession();
		Transaction tran = session.beginTransaction();
		
		session.update(user);
		
		tran.commit();
		session.close();
	}

	public void delete(User user){
		Session session = HibernateSessionFactory.getSession();
		Transaction tran = session.beginTransaction();
		
		session.delete(user);
		
		tran.commit();
		session.close();
	}
	
	public User findById(Integer id){
		Session session = HibernateSessionFactory.getSession();
		Transaction tran = session.beginTransaction();
		
		User user = (User)session.get(User.class, id);
		
		tran.commit();
		session.close();
		
		return user;
	}
	
	public List<User> findAll(){
		Session session = HibernateSessionFactory.getSession();
		Transaction tran = session.beginTransaction();
		String hql = "from User";
		Query query = session.createQuery(hql);
		List<User> list= query.list();
		
		
		tran.commit();
		session.close();
		
		return list;
	}

	

}
