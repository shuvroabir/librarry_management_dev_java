create table Users(
     UserName nvarchar(20) not null,
	 Password nvarchar(20) not null,
	 Realname nvarchar(20) not null,
	 Age int not null,
	 Gender nvarchar(20) not null,
	 Email nvarchar(30) not null,
	 QQ nvarchar(20) not null,
	 Remark nvarchar(MAX) not null
)